import { Component } from '@angular/core';

@Component({
  selector: 'ngx-modal-overlays',
  template: `
    <router-outlet></router-outlet>
  `,
})

export class ModalOverlaysComponent {
}
